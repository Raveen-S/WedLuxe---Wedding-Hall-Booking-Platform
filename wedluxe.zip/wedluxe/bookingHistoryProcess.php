<?php
session_start();
$val = $_GET["Cid"];

// Database connection
$host = "localhost";
$user = "root";
$password = "MySQLRv0712";
$dbname = "Wedding_Management";

$connection = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$Bookings = array();

// Query for hotel bookings with order date in descending order
$queryHotel = "SELECT *, `wedding_date` AS `booking_date` FROM `hotel_booking` WHERE `user_email` = '" . $_SESSION["user_email"] . "' AND `hidden` = '0' AND `order_status` = 'confirmed' ORDER BY `order_date` DESC";
$purchase_rs = mysqli_query($connection, $queryHotel);

if ($purchase_rs) {
    $hotelBookings = array();
    while ($row = mysqli_fetch_assoc($purchase_rs)) {
        $row['booking_type'] = 'hotel_booking';
        $hotelBookings[] = $row;
    }
    $Bookings['hotel_bookings'] = $hotelBookings;
} else {
    echo "Error executing the hotel booking query: " . mysqli_error($connection);
}

$mergedBookings = array_merge($Bookings['hotel_bookings']);

if ($val == "1") {
    usort($mergedBookings, function ($a, $b) {
        return strtotime($b['order_date']) - strtotime($a['order_date']);
    });
} else {
    usort($mergedBookings, function ($a, $b) {
        $today = strtotime(date('Y-m-d'));
        $bookingDateA = strtotime($a['booking_date']);
        $bookingDateB = strtotime($b['booking_date']);
        $daysDifferenceA = ($bookingDateA > $today) ? ($bookingDateA - $today) / (60 * 60 * 24) : PHP_INT_MAX;
        $daysDifferenceB = ($bookingDateB > $today) ? ($bookingDateB - $today) / (60 * 60 * 24) : PHP_INT_MAX;
        return $daysDifferenceA - $daysDifferenceB;
    });
}

?>

<?php
$val_id = "";

if (empty($mergedBookings)) {
?>
    <div class="col-12 bg-light text-center">
        <span style="margin-top: 200px;margin-bottom:200px;" class="fs-5 fw-bold text-black-50 d-block">
            You Have No Items In Your history Yet...
        </span>
    </div>
    <?php
} else {
    foreach ($mergedBookings as $booking) {

        $val_id = "0";
        $query = "SELECT * FROM `packages` WHERE `id` = '" . $booking["packag_id"] . "'";
        $product_rs = mysqli_query($connection, $query);
        $product_data = $product_rs->fetch_assoc();

        $query1 = "SELECT `hotels`.`name`, `hotels`.`id`, `hotel_img_logo`.`image` 
           FROM `hotels` 
           INNER JOIN `hotel_img_logo` ON `hotels`.`id` = `hotel_img_logo`.`hotel_id` 
           WHERE `hotels`.`id` = '" . $product_data["hotel_id"] . "'";
        $image_rs = mysqli_query($connection, $query1);
        $image_data = $image_rs->fetch_assoc();
    ?>

        <!-- Alert -->
        <div id="custom-dialog" style="display: none;">
            <div id="customAlert" style="text-align: center;" class="message ">Do you want to continue?</div>
            <div class="buttons">
                <button id="custom-no">No</button>
                <button id="custom-yes">Yes</button>
            </div>
        </div>
        <!-- Alert -->

        <div class="col-12 mt-0">
            <div class="row">
                <div class="col-1 mx-3 mt-4 mb-1">
                    <div class="row">
                        <span class="text-start fs-2 d-flex align-items-center" style="font-family: 'Poppins', sans-serif; color: #3E3E3E;">
                            <img style="width: 43px;" src="images/Logo.jpg" /><?php echo $booking['booking_type'] ?>
                        </span>
                    </div>
                </div>

                <div class="col-12">
                    <div style="display: flex; height: max-content; border:1px solid #aaa; border-radius:10px; overflow:hidden;">
                        <div style="background-color: #17A2B8; padding: 10px; text-align: center; width:min-content;">
                            <label style="font-family: 'Roboto', sans-serif; font-size: 16px; color: white; font-weight: bold;">Order_id</label>
                            <span style="display: block; padding-top: 10px; font-size: 14px; color: white;"><?php echo $booking['order_id']; ?></span>
                        </div>

                        <div style="width:max-content; padding:0px 15px;">
                            <label style="display: block; margin-top: 10px; font-family: 'Roboto', sans-serif; font-size: 16px; font-weight: bold;">Order Details</label>

                            <div style="display: flex; margin-top: 0px; flex-direction:column;">
                                <div style="width: 160px;">
                                    <img src="images/hotels/<?php echo $image_data['image']; ?>" style="width: 100%; border-radius: 5px;">
                                </div>
                                <div style="margin-left: 0px;">
                                    <h6 style="font-family: 'Poppins', sans-serif; margin: 0;"><?php echo $image_data['name']; ?></h6>
                                    <p style="font-size: 14px; margin: 5px 0;"><b>Package:</b> <?php echo $product_data['package_type']; ?></p>
                                    <p style="font-size: 14px; margin: 5px 0;"><b>Order Date:</b> <?php echo $booking['order_date']; ?></p>
                                </div>
                            </div>
                        </div>

                        <div style="background-color: #17A2B8; padding: 20px; text-align: center; flex: 2;">
                            <label style="font-family: 'Roboto', sans-serif; font-size: 16px; font-weight: bold; color: #FFF;">Amount</label>
                            <span style="display: block; font-size: 24px; color: white;">Rs.<?php echo $product_data['price']; ?>.00</span>
                        </div>

                        <div style="background-color: #E9ECEF; padding: 20px; text-align: center; flex: 2;">
                            <label style="font-family: 'Roboto', sans-serif; font-size: 16px; font-weight: bold;">Wedding date</label>
                            <span style="display: block; font-size: 24px;"><?php echo $booking['wedding_date']; ?></span>
                        </div>

                        <div style=" padding: 20px; text-align: center;">
                            <div style="display:flex; flex-direction:column; gap:5px;">
                                <button onclick="showFeedbackModel('<?php echo $image_data['id'] ?>','<?php echo $image_data['name'] ?>','', '<?php echo $val_id ?>')" style="padding: 3px; border: 1px solid #007BFF; background: none; color: #007BFF; font-size: 18px; border-radius: 5px;">
                                    <i class="bi bi-info-circle-fill"></i> Feedback
                                </button>

                                <?php
                                $d = new DateTime();
                                $tz = new DateTimezone("Asia/Colombo");
                                $d->setTimezone($tz);
                                $date = $d->format("Y-m-d");

                                if ($date < $booking["wedding_date"]) {
                                ?>
                                    <button onclick="cancelbooking('<?php echo $booking['id']; ?>', '<?php echo $val_id ?>');" style="padding: 10px; background-color: #FFC107; color: white; border: none; font-size: 14px; border-radius: 5px;">
                                        <i class="bi bi-x-lg"></i> Cancel
                                    </button>

                                    <button onclick="deleteFromPHistory('<?php echo $booking['id']; ?>', '<?php echo $val_id ?>');" style="padding: 10px; background-color: #DC3545; color: white; border: none; font-size: 18px; border-radius: 5px;">
                                        <i class="bi bi-trash-fill"></i>
                                    </button>
                                <?php } else { ?>
                                    <button onclick="deleteFromPHistory('<?php echo $booking['id']; ?>', '<?php echo $val_id ?>');" style="padding: 10px; background-color: #DC3545; color: white; border: none; font-size: 18px; border-radius: 5px;">
                                        <i class="bi bi-trash-fill"></i> Delete
                                    </button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

<?php
    }
}
?>