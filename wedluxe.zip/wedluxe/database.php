class Database {
public static function search($query) {
// Assuming there's a connection setup inside this function
global $connection; // Or use a connection method inside the class
return mysqli_query($connection, $query);
}
}