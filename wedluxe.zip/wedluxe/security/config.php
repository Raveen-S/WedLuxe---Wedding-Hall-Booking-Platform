<?php
// Email Settings
define("EMAIL", "test@gmail.com"); // 2 step verified Email for sending mails through the site 
define("PASSWORD", "key"); // app key for the mail

//  Database connection settings
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "password");  // change password
define("DB_NAME", "Wedding_Management");
define("DB_PORT", 3306);
