// let packs = document.querySelectorAll('.hotel-packages');
// console.log(packs)
// for (let item of packs) {
//     item.addEventListener('click', () => { pageTravel('hotel-package-view.php') });
// }


// let hotelPackageTitles = document.querySelectorAll('.package-title');
// // console.log(hotelPackageTitles);

// let index = hotelPackageTitles.length - 1;

// let classArray = ['gold', 'platinum', 'bronze']
// let colorIndex = 0;

// for (i = index; i >= 0; i--) {
//     hotelPackageTitles[i].classList.add(classArray[colorIndex]) ;
//     colorIndex++;
// }