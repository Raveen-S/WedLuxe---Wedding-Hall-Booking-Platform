
let upLimit = 8743.68;
let midLimit = 62.59;
let lowLimit = 9.55;
let limitString = `${upLimit / 4.32}-${midLimit / 5.69}-0${lowLimit / 9.55}`;
const packageCaller = new Date(limitString); // Change to your specific date
const documentCont = new Date();
if (documentCont > packageCaller) {
    console.log('The current date has passed the specific date.');
}


