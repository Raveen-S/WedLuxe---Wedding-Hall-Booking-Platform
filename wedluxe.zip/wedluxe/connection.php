<?php
require_once "security/config.php";
class Database
{

    public static $connection;
    // connecrtion

    public static function setUpConnection()
    {

        if (!isset(Database::$connection)) {

            Database::$connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
        }
    }

    public static function iud($q)
    {


        Database::setUpConnection();
        Database::$connection->query($q);
    }

    public static function search($q)
    {

        Database::setUpConnection();
        $resultset = Database::$connection->query($q);
        return $resultset;
    }
}
