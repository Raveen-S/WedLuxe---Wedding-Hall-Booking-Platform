-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.26 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table wedding_management.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `otp` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `type` int DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`),
  KEY `FK_admin_admin_type` (`type`),
  CONSTRAINT `FK_admin_admin_type` FOREIGN KEY (`type`) REFERENCES `admin_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.admin: ~0 rows (approximately)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`email`, `fname`, `lname`, `otp`, `type`, `status`) VALUES
	('admin@gmail.com', 'admin', 'admin', '668049dd7915a', 1, 0);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Dumping structure for table wedding_management.admin_type
CREATE TABLE IF NOT EXISTS `admin_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.admin_type: ~2 rows (approximately)
/*!40000 ALTER TABLE `admin_type` DISABLE KEYS */;
INSERT INTO `admin_type` (`id`, `name`) VALUES
	(1, 'super admin'),
	(2, 'admin');
/*!40000 ALTER TABLE `admin_type` ENABLE KEYS */;

-- Dumping structure for table wedding_management.bookings
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `meetup_id` int NOT NULL,
  `time_slot` time NOT NULL,
  `date` date NOT NULL,
  `booked_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.bookings: ~3 rows (approximately)
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` (`id`, `user_id`, `meetup_id`, `time_slot`, `date`, `booked_at`) VALUES
	(30, 1, 1, '09:00:00', '2024-06-15', '2024-06-14 14:41:41'),
	(31, 2, 1, '10:00:00', '2024-06-15', '2024-06-14 14:53:02'),
	(32, 4, 1, '11:00:00', '2024-06-15', '2024-06-14 14:56:03'),
	(33, 18, 1, '12:00:00', '2024-06-16', '2024-06-16 08:43:26'),
	(34, 18, 1, '09:00:00', '2024-06-26', '2024-06-26 15:16:48'),
	(35, 18, 1, '11:00:00', '2024-06-26', '2024-06-26 15:32:41'),
	(36, 18, 1, '11:30:00', '2024-06-26', '2024-06-26 15:37:48'),
	(37, 18, 1, '12:00:00', '2024-06-26', '2024-06-26 16:00:22'),
	(38, 24, 1, '09:00:00', '2024-07-05', '2024-07-02 17:11:19'),
	(39, 25, 1, '17:00:00', '2024-07-07', '2024-07-04 17:48:28'),
	(43, 15, 1, '15:00:00', '2024-07-11', '2024-07-07 08:11:09'),
	(44, 26, 1, '17:00:00', '2024-07-11', '2024-07-08 10:04:58'),
	(45, 26, 1, '10:30:00', '2024-07-11', '2024-07-08 10:32:32'),
	(46, 26, 1, '12:00:00', '2024-08-15', '2024-07-25 14:03:10'),
	(47, 2, 1, '09:00:00', '2024-08-05', '2024-08-02 15:44:49'),
	(48, 28, 1, '17:00:00', '2024-09-01', '2024-08-31 17:51:04');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;

-- Dumping structure for table wedding_management.booking_payment
CREATE TABLE IF NOT EXISTS `booking_payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `booking_id` int DEFAULT NULL,
  `card_num` varchar(20) DEFAULT NULL,
  `card_year` varchar(6) DEFAULT NULL,
  `card-month` varchar(5) DEFAULT NULL,
  `paymentNo` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `total` double DEFAULT NULL,
  `Amount_paid` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_booking_payment_users` (`user_email`),
  KEY `FK_booking_payment_category` (`category_id`),
  CONSTRAINT `FK_booking_payment_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK_booking_payment_users` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.booking_payment: ~0 rows (approximately)
/*!40000 ALTER TABLE `booking_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_payment` ENABLE KEYS */;

-- Dumping structure for table wedding_management.category
CREATE TABLE IF NOT EXISTS `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.category: ~4 rows (approximately)
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`, `name`) VALUES
	(0, '\r\nHotels'),
	(1, 'Dj'),
	(2, 'Photography'),
	(3, 'Vehicles');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;

-- Dumping structure for table wedding_management.condition
CREATE TABLE IF NOT EXISTS `condition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.condition: ~2 rows (approximately)
/*!40000 ALTER TABLE `condition` DISABLE KEYS */;
INSERT INTO `condition` (`id`, `name`) VALUES
	(1, 'available'),
	(2, 'not available');
/*!40000 ALTER TABLE `condition` ENABLE KEYS */;

-- Dumping structure for table wedding_management.district
CREATE TABLE IF NOT EXISTS `district` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `province_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_district_province` (`province_id`),
  CONSTRAINT `FK_district_province` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.district: ~25 rows (approximately)
/*!40000 ALTER TABLE `district` DISABLE KEYS */;
INSERT INTO `district` (`id`, `name`, `province_id`) VALUES
	(1, 'Jaffna', 3),
	(2, 'Kilinochchi', 3),
	(3, 'Mannar', 3),
	(4, 'Mullaitivu', 3),
	(5, 'Vavuniya', 3),
	(6, 'Puttalam', 6),
	(7, 'Kurunegala', 6),
	(8, 'Gampaha', 5),
	(9, 'Colombo', 5),
	(10, 'Anuradhapura', 7),
	(11, 'Polonnaruwa', 7),
	(12, 'Matale', 1),
	(13, 'Kandy', 1),
	(14, 'Nuwara Eliya', 1),
	(15, 'Kegalle', 9),
	(16, 'Ratnapura', 9),
	(17, 'Trincomalee', 2),
	(18, 'Batticaloa', 2),
	(19, 'Ampara', 2),
	(20, 'Badulla', 8),
	(21, 'Monaragala', 8),
	(22, 'Hambantota', 4),
	(23, 'Matara', 4),
	(24, 'Galle', 4),
	(25, 'kaluthara', 5);
/*!40000 ALTER TABLE `district` ENABLE KEYS */;

-- Dumping structure for table wedding_management.dj
CREATE TABLE IF NOT EXISTS `dj` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `seller_email` varchar(50) DEFAULT NULL,
  `line1` varchar(50) DEFAULT NULL,
  `line2` varchar(50) DEFAULT NULL,
  `districts_id` int DEFAULT NULL,
  `discription` text,
  `company_name` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '0',
  `pay_id` int DEFAULT NULL,
  `register_payment` double DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dj_users` (`seller_email`),
  KEY `FK_dj_district` (`districts_id`),
  KEY `FK_dj_pay_type` (`pay_id`),
  CONSTRAINT `FK_dj_district` FOREIGN KEY (`districts_id`) REFERENCES `district` (`id`),
  CONSTRAINT `FK_dj_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_dj_users` FOREIGN KEY (`seller_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.dj: ~0 rows (approximately)
/*!40000 ALTER TABLE `dj` DISABLE KEYS */;
/*!40000 ALTER TABLE `dj` ENABLE KEYS */;

-- Dumping structure for table wedding_management.dj_booking
CREATE TABLE IF NOT EXISTS `dj_booking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `time_id` int DEFAULT NULL,
  `packag_id` int DEFAULT NULL,
  `hidden` int DEFAULT '0',
  `order_id` varchar(50) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `order_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'confirmed',
  `pay_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dj_booking_users` (`user_email`),
  KEY `FK_dj_booking_time` (`time_id`),
  KEY `FK_dj_booking_dj_package` (`packag_id`),
  KEY `FK_dj_booking_pay_type` (`pay_id`),
  CONSTRAINT `FK_dj_booking_dj_package` FOREIGN KEY (`packag_id`) REFERENCES `dj_package` (`id`),
  CONSTRAINT `FK_dj_booking_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_dj_booking_time` FOREIGN KEY (`time_id`) REFERENCES `time` (`id`),
  CONSTRAINT `FK_dj_booking_users` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.dj_booking: ~0 rows (approximately)
/*!40000 ALTER TABLE `dj_booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `dj_booking` ENABLE KEYS */;

-- Dumping structure for table wedding_management.dj_gallary
CREATE TABLE IF NOT EXISTS `dj_gallary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `dj_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dj_gallary_dj` (`dj_id`) USING BTREE,
  CONSTRAINT `FK_dj_gallary_dj` FOREIGN KEY (`dj_id`) REFERENCES `dj` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.dj_gallary: ~0 rows (approximately)
/*!40000 ALTER TABLE `dj_gallary` DISABLE KEYS */;
/*!40000 ALTER TABLE `dj_gallary` ENABLE KEYS */;

-- Dumping structure for table wedding_management.dj_img_logo
CREATE TABLE IF NOT EXISTS `dj_img_logo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dj_id` int DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dj__img_logo_dj` (`dj_id`),
  CONSTRAINT `FK_dj__img_logo_dj` FOREIGN KEY (`dj_id`) REFERENCES `dj` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.dj_img_logo: ~0 rows (approximately)
/*!40000 ALTER TABLE `dj_img_logo` DISABLE KEYS */;
/*!40000 ALTER TABLE `dj_img_logo` ENABLE KEYS */;

-- Dumping structure for table wedding_management.dj_package
CREATE TABLE IF NOT EXISTS `dj_package` (
  `id` int NOT NULL AUTO_INCREMENT,
  `package_type` varchar(50) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `preview_image` varchar(50) DEFAULT NULL,
  `dj_id` int DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_dj_package_hotels` (`dj_id`),
  CONSTRAINT `FK_dj_package_dj` FOREIGN KEY (`dj_id`) REFERENCES `dj` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.dj_package: ~0 rows (approximately)
/*!40000 ALTER TABLE `dj_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `dj_package` ENABLE KEYS */;

-- Dumping structure for table wedding_management.dj_package_features
CREATE TABLE IF NOT EXISTS `dj_package_features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `package_id` int DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dj_package_features_dj_package` (`package_id`),
  CONSTRAINT `FK_dj_package_features_dj_package` FOREIGN KEY (`package_id`) REFERENCES `dj_package` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.dj_package_features: ~0 rows (approximately)
/*!40000 ALTER TABLE `dj_package_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `dj_package_features` ENABLE KEYS */;

-- Dumping structure for table wedding_management.events
CREATE TABLE IF NOT EXISTS `events` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.events: ~4 rows (approximately)
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` (`id`, `title`, `description`, `start`, `end`) VALUES
	(3, 'pet selling', 'new event', '2024-05-03 00:00:00', '2024-05-04 23:59:59'),
	(4, 'exhibition', 'special', '2024-05-22 00:00:00', '2024-05-24 23:59:59'),
	(5, 'pet exhibition', '2nd exhibition in pet palooza', '2024-07-09 00:00:00', '2024-07-12 23:59:59'),
	(11, 'seminar', 'hiiiiiii', '2024-07-26 00:00:00', '2024-08-02 23:59:59');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;

-- Dumping structure for table wedding_management.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) DEFAULT NULL,
  `bok_id` int DEFAULT NULL,
  `feed` text,
  `date` datetime DEFAULT NULL,
  `star` int DEFAULT NULL,
  `booking_table_id` int DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_feedback_users` (`user_email`),
  KEY `FK_feedback_category` (`booking_table_id`),
  CONSTRAINT `FK_feedback_category` FOREIGN KEY (`booking_table_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK_feedback_users` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.feedback: ~0 rows (approximately)
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;

-- Dumping structure for table wedding_management.feedback_img
CREATE TABLE IF NOT EXISTS `feedback_img` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(80) DEFAULT NULL,
  `feedback_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_feedback_img_feedback` (`feedback_user`),
  CONSTRAINT `FK_feedback_img_feedback` FOREIGN KEY (`feedback_user`) REFERENCES `feedback` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.feedback_img: ~0 rows (approximately)
/*!40000 ALTER TABLE `feedback_img` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback_img` ENABLE KEYS */;

-- Dumping structure for table wedding_management.gallary
CREATE TABLE IF NOT EXISTS `gallary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(100) DEFAULT NULL,
  `hotel_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_gallary_hotels` (`hotel_id`),
  CONSTRAINT `FK_gallary_hotels` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.gallary: ~0 rows (approximately)
/*!40000 ALTER TABLE `gallary` DISABLE KEYS */;
/*!40000 ALTER TABLE `gallary` ENABLE KEYS */;

-- Dumping structure for table wedding_management.hotels
CREATE TABLE IF NOT EXISTS `hotels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `seller_email` varchar(50) DEFAULT NULL,
  `line1` varchar(50) DEFAULT NULL,
  `line2` varchar(50) DEFAULT NULL,
  `districts_id` int DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `discription` text,
  `status` int DEFAULT '0',
  `pay_id` int DEFAULT NULL,
  `register_payment` double DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_hotels_users` (`seller_email`),
  KEY `FK_hotels_district` (`districts_id`),
  KEY `FK_hotels_pay_type` (`pay_id`),
  CONSTRAINT `FK_hotels_district` FOREIGN KEY (`districts_id`) REFERENCES `district` (`id`),
  CONSTRAINT `FK_hotels_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_hotels_users` FOREIGN KEY (`seller_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.hotels: ~0 rows (approximately)
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;

-- Dumping structure for table wedding_management.hotel_booking
CREATE TABLE IF NOT EXISTS `hotel_booking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `wedding_date` date NOT NULL,
  `time_id` int DEFAULT NULL,
  `packag_id` int DEFAULT NULL,
  `hidden` int DEFAULT '0',
  `order_id` varchar(50) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `order_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'confirmed',
  `pay_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_booking_users` (`user_email`) USING BTREE,
  KEY `FK_hotel_booking_time` (`time_id`),
  KEY `FK_hotel_booking_packages` (`packag_id`),
  KEY `FK_hotel_booking_pay_type` (`pay_id`),
  CONSTRAINT `FK_booking_users` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`),
  CONSTRAINT `FK_hotel_booking_packages` FOREIGN KEY (`packag_id`) REFERENCES `packages` (`id`),
  CONSTRAINT `FK_hotel_booking_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_hotel_booking_time` FOREIGN KEY (`time_id`) REFERENCES `time` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.hotel_booking: ~0 rows (approximately)
/*!40000 ALTER TABLE `hotel_booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel_booking` ENABLE KEYS */;

-- Dumping structure for table wedding_management.hotel_img_logo
CREATE TABLE IF NOT EXISTS `hotel_img_logo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_hotel_img_logo_hotels` (`hotel_id`),
  CONSTRAINT `FK_hotel_img_logo_hotels` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.hotel_img_logo: ~0 rows (approximately)
/*!40000 ALTER TABLE `hotel_img_logo` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel_img_logo` ENABLE KEYS */;

-- Dumping structure for table wedding_management.job_applications
CREATE TABLE IF NOT EXISTS `job_applications` (
  `id` int NOT NULL,
  `vacancy_id` int NOT NULL,
  `user_id` int NOT NULL,
  `resume_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.job_applications: ~12 rows (approximately)
/*!40000 ALTER TABLE `job_applications` DISABLE KEYS */;
INSERT INTO `job_applications` (`id`, `vacancy_id`, `user_id`, `resume_path`, `application_date`) VALUES
	(11, 5, 1, './uploads/resumes/0f9dc8e99f796cd0b363eda88e81c44f.docx', '2024-06-16 08:11:14'),
	(12, 5, 18, './uploads/resumes/ca639d8b0b8fd6bb3a42a502c1eee937.pdf', '2024-06-27 19:00:53'),
	(13, 4, 18, './uploads/resumes/29f517686f349768015afca33c742e69.pdf', '2024-06-27 19:44:15'),
	(14, 5, 18, './uploads/resumes/07977b13d441fae209a9b032d461f66f.pdf', '2024-06-27 19:49:19'),
	(15, 8, 18, './uploads/resumes/fb9a24de4f638071b62f0a0739084257.docx', '2024-06-27 20:07:55'),
	(16, 4, 18, './uploads/resumes/cb680374e241a78f8151a28e63dec56f.docx', '2024-06-27 20:10:19'),
	(17, 10, 24, './uploads/resumes/3be3f6b2f30077e0fe4fcd4beb7d87d4.docx', '2024-07-02 17:15:07'),
	(18, 10, 25, './uploads/resumes/82079bb8f37fad2fe8d68e08ee774474.jpg', '2024-07-04 17:52:45'),
	(22, 12, 26, './uploads/resumes/6ad424cfe155505b9f62ef65b2a66d11.pdf', '2024-07-08 10:35:09'),
	(23, 11, 26, './uploads/resumes/a194f234f345f5b2134ecdc8f8f2a4ef.pdf', '2024-07-25 14:04:21'),
	(24, 12, 2, './uploads/resumes/92c6b6a8e62fc7d68d4687658d73821e.pdf', '2024-08-02 15:46:05'),
	(25, 10, 28, './uploads/resumes/50364e1477b84355a9017e7a66523938.pdf', '2024-08-31 17:57:14');
/*!40000 ALTER TABLE `job_applications` ENABLE KEYS */;

-- Dumping structure for table wedding_management.job_vacancies
CREATE TABLE IF NOT EXISTS `job_vacancies` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `salary` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.job_vacancies: ~3 rows (approximately)
/*!40000 ALTER TABLE `job_vacancies` DISABLE KEYS */;
INSERT INTO `job_vacancies` (`id`, `title`, `description`, `location`, `salary`, `created_at`, `image`) VALUES
	(10, 'Pet Store Manager', 'Responsible for overseeing all aspects of store operations, including staff management, inventory control, and customer service. The manager sets sales targets, implements marketing strategies, and ensures compliance with health and safety regulations. Additional responsibilities include financial management, preparing reports, handling customer complaints, and organizing promotional events. The ideal candidate has strong leadership skills and experience in retail management.', 'warakapola, kegalle', '$40,000/year', '2024-06-27 20:11:23', '64bc085d599379cc5bdaab57be21e30e.png'),
	(11, 'Veterinary Assistant', 'Assist veterinarians with medical procedures, such as examinations, vaccinations, surgeries, and dental cleanings. Veterinary assistants are responsible for restraining animals during procedures, preparing and sterilizing instruments, administering medications, and performing diagnostic tests. A background in veterinary care, along with strong organizational and communication skills, is required.', 'warakapola, kegalle', '$30,000/year', '2024-07-06 06:20:41', 'd20c1a7b1f7b4ee04a40c2dac1387076.png'),
	(12, 'Pet Care Specialist', ' Oversee the daily care and well-being of the pets in the store, including feeding, cleaning enclosures, monitoring health, and providing enrichment activities.  Pet care specialists educate customers on pet care best practices, assist with pet adoptions, and handle minor health issues. A strong understanding of animal behavior and health, as well as experience working with animals, is essential for this role.', 'warakapola, kegalle', '$35,000/year', '2024-07-06 06:32:09', 'b1b330d9eb46c4256d14549d8eba021d.jpg');
/*!40000 ALTER TABLE `job_vacancies` ENABLE KEYS */;

-- Dumping structure for table wedding_management.meetings
CREATE TABLE IF NOT EXISTS `meetings` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `zoom_link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `meeting_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `passcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `booking_id` int DEFAULT NULL,
  `scheduled_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.meetings: ~14 rows (approximately)
/*!40000 ALTER TABLE `meetings` DISABLE KEYS */;
INSERT INTO `meetings` (`id`, `user_id`, `user_name`, `user_email`, `zoom_link`, `meeting_id`, `passcode`, `booking_id`, `scheduled_at`) VALUES
	(23, 1, 'ridmi chethana', 'ridmi@gmail.com', 'https://teams.microsoft.com/l/meetup-join/19%3ameeting_ZjAyOThlNjktNzk0OS00ZDZiLTg1ZTItMWJhZDUwM2RiYTA1%40thread.v2/0?context=%7b%22Tid%22%3a%2267208f32-4ce9-4096-8273-c1342009bb1c%22%2c%22Oid%22%3a%22bec5a8d4-db1f-4111-832a-cd0a3b2d3644%22%7d2', '555', 'ridmi', 30, '2024-06-14 20:13:15'),
	(24, 2, 'dushan weerakoon', 'dushan@gmail.com', 'https://us05web.zoom.us/j/84131926996?pwd=3N9mS45fw0paGNDIEbbtnw0f0yaN5H.1', '459', 'ggugo', 31, '2024-06-14 20:23:57'),
	(25, 18, 'dinoshi sewwandi', 'dinoshisewwandi7@gmail.com', '1234dfdf', '5466', '1234', 34, '2024-06-26 20:49:16'),
	(26, 18, 'dinoshi sewwandi', 'dinoshisewwandi7@gmail.com', '232342', '5465', 'fgf', 33, '2024-06-26 20:54:22'),
	(27, 4, 'Jane Smith', 'jane.smith@example.com', 're4', '466564', '454', 32, '2024-06-26 20:56:00'),
	(28, 18, 'dinoshi sewwandi', 'dinoshisewwandi7@gmail.com', '1234', '1212', '456', 35, '2024-06-26 21:02:59'),
	(29, 18, 'dinoshi sewwandi', 'dinoshisewwandi7@gmail.com', '123', '123', 'q123', 36, '2024-06-26 21:13:30'),
	(30, 24, 'ishara sewwandi', 'ishara@gmail.com', 'dgfdgfc', '5596', 'lkj', 38, '2024-07-02 22:50:55'),
	(31, 25, 'vikum gunawardana', 'vikum12801999@gmail.com', 'trht', '5466545', 'fgjtnbjh', 39, '2024-07-04 23:19:49'),
	(35, 26, 'chethi ketayamge', 'chethiketayamge@gmail.com', 'https://us05web.zoom.us/j/84131926996?pwd=3N9mS45fw0paGNDIEbbtnw0f0yaN5H.1', '465', '4646', 45, '2024-07-08 16:03:08'),
	(36, 26, 'chethi ketayamge', 'chethiketayamge@gmail.com', 'https://us05web.zoom.us/j/84131926996?pwd=3N9mS45fw0paGNDIEbbtnw0f0yaN5H.1', '123456', 'bhgd63e', 46, '2024-07-25 19:36:28'),
	(37, 2, 'dinoshi sewwandi', 'dinosewwandi@gmail.com', 'https://us05web.zoom.us/j/84131926996?pwd=3N9mS45fw0paGNDIEbbtnw0f0yaN5H.1', '54545', 'jbjkbk', 47, '2024-08-02 21:17:33'),
	(38, 15, 'wathsala rathnayake', 'wathsala@gmail.com', 'https://us05web.zoom.us/j/84131926996?pwd=3N9mS45fw0paGNDIEbbtnw0f0yaN5H.1', '6546546', 'hgh5646mknk', 43, '2024-08-13 21:53:18'),
	(39, 28, 'Thavisha Saknidu', 'thaveesha.sathnidu2007@gmail.com', 'https://us05web.zoom.us/j/84131926996?pwd=3N9mS45fw0paGNDIEbbtnw0f0yaN5H.1', '45465464', 'fgddyhdt', 48, '2024-08-31 23:21:53');
/*!40000 ALTER TABLE `meetings` ENABLE KEYS */;

-- Dumping structure for table wedding_management.meetups
CREATE TABLE IF NOT EXISTS `meetups` (
  `id` int NOT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.meetups: ~0 rows (approximately)
/*!40000 ALTER TABLE `meetups` DISABLE KEYS */;
INSERT INTO `meetups` (`id`, `date`, `created_at`) VALUES
	(1, '2024-06-01', '2024-05-31 18:08:41');
/*!40000 ALTER TABLE `meetups` ENABLE KEYS */;

-- Dumping structure for table wedding_management.notices
CREATE TABLE IF NOT EXISTS `notices` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.notices: ~4 rows (approximately)
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` (`id`, `title`, `description`, `image`, `created_at`) VALUES
	(10, 'New Arrivals This Week!', 'We are excited to announce that we have new puppies and kittens available for adoption this week. Come visit us to meet our adorable new pets and find your perfect furry friend. Our team is here to help with any questions and provide you with all the information you need to choose the right pet for your family.', 'uploads/pet_arival.webp', '2024-07-06 08:43:47'),
	(11, 'Summer Pet Care Tips', 'As summer heats up, it’s important to keep your pets cool and comfortable. Check out our latest blog post for tips on how to keep your pets hydrated, provide shade, and prevent heatstroke. Our store also has a range of summer essentials for your pets, including cooling mats and hydration packs.', 'uploads/summertime-grooming-tips_header.jpg', '2024-07-06 08:45:59'),
	(12, 'Adoption Event This Weekend!', 'Join us for our special adoption event this Saturday from 10 AM to 4 PM. We will have a variety of pets ready for adoption, including dogs, cats, and small animals. Adoption fees will be waived for the event, and there will be fun activities for the whole family. Don’t miss out on the chance to find your new best friend!', 'uploads/organize-a-local-pet-adoption-event-632x304.jpg', '2024-07-06 08:48:22'),
	(13, 'Special Discounts on Pet Supplies', 'Enjoy exclusive discounts on a wide range of pet supplies, including food, toys, and grooming products. Visit our store to take advantage of these special offers and ensure your pet has everything they need. Discounted prices are available for a limited time only, so be sure to stop by soon!', 'uploads/pet discount.jpeg', '2024-07-06 08:50:50');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;

-- Dumping structure for table wedding_management.packages
CREATE TABLE IF NOT EXISTS `packages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `package_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `preview_image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `hotel_id` int DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_packages_hotels` (`hotel_id`),
  CONSTRAINT `FK_packages_hotels` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.packages: ~0 rows (approximately)
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;

-- Dumping structure for table wedding_management.package_features
CREATE TABLE IF NOT EXISTS `package_features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `package_id` int NOT NULL,
  `title` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `FK_package_features_packages` (`package_id`) USING BTREE,
  CONSTRAINT `FK_package_features_packages` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.package_features: ~0 rows (approximately)
/*!40000 ALTER TABLE `package_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_features` ENABLE KEYS */;

-- Dumping structure for table wedding_management.pay_type
CREATE TABLE IF NOT EXISTS `pay_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.pay_type: ~2 rows (approximately)
/*!40000 ALTER TABLE `pay_type` DISABLE KEYS */;
INSERT INTO `pay_type` (`id`, `name`) VALUES
	(1, 'paid'),
	(2, 'not paid');
/*!40000 ALTER TABLE `pay_type` ENABLE KEYS */;

-- Dumping structure for table wedding_management.pets
CREATE TABLE IF NOT EXISTS `pets` (
  `id` int NOT NULL,
  `pet_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `brand` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `gender` enum('Male','Female') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'stock'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.pets: ~30 rows (approximately)
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
INSERT INTO `pets` (`id`, `pet_type`, `brand`, `country`, `age`, `gender`, `price`, `description`, `image`, `status`) VALUES
	(8, 'fish', 'gold fish', 'modives', 90, 'Male', 5000.00, 'no', '4.jpg', 'stock'),
	(10, 'dog', 'lionsheperd', 'modives', 8, 'Male', 8800.00, 'no', '6.jpg', 'sold'),
	(11, 'cat', 'Siamese', 'Thailand ', 1, 'Male', 8000.00, 'Known for their sleek, slender bodies, striking blue almond-shaped eyes, and distinctive color points on their ears, face, paws, and tail.', 'cat1.jpg', 'stock'),
	(12, 'cat', 'Maine Coon', 'united state', 3, 'Male', 12000.00, ' One of the largest domesticated cat breeds, Maine Coons have long, thick fur, tufted ears, and a bushy tail. They are known for their friendly and sociable nature.', 'cat2.jpg', 'stock'),
	(13, 'cat', 'Persian', 'Iran', 1, 'Male', 6000.00, 'Recognizable by their long, luxurious fur and flat, pushed-in faces, Persians are a popular breed known for their calm and gentle demeanor.', 'cat3.jpg', 'sold'),
	(14, 'cat', 'bengal', 'United States', 3, 'Male', 7000.00, 'Bengals have a wild appearance with large spots and rosettes reminiscent of a leopard\'s coat. They are active, playful, and intelligent cats.\r\n', 'cat4.jpg', 'stock'),
	(15, 'cat', 'British Shorthair', 'united kindom', 4, 'Female', 4000.00, 'Known for their dense, plush coat and round face with large, round eyes. They have a calm and affectionate nature.', 'cat5.jpg', 'stock'),
	(16, 'cat', 'Abyssinian', 'ithiopia', 2, 'Female', 5500.00, 'Recognizable by their short, ticked coat and active, playful demeanor. They have a slender, athletic build and are very curious.', 'cat6.webp', 'stock'),
	(17, 'dog', 'Labrador Retriever', 'canada', 1, 'Male', 10000.00, 'Friendly, outgoing, and high-spirited companions, Labradors are popular for their intelligence and trainability.', 'labrador.jpg', 'sold'),
	(18, 'dog', 'German Shepherd', 'germany', 3, 'Male', 20000.00, 'Known for their courage, loyalty, and guarding instincts, German Shepherds are highly versatile working dogs.', 'germen_shpeperd.jpg', 'sold'),
	(19, 'dog', 'Golden Retriever', 'scotland', 1, 'Female', 10000.00, ' Intelligent, friendly, and devoted, Golden Retrievers are popular family pets and excellent working dogs.', 'Golden Retriever.jpg', 'sold'),
	(20, 'dog', 'bulldog', 'England', 2, 'Female', 18000.00, 'Bulldogs have a distinctive wrinkled face and pushed-in nose. They are gentle, affectionate, and good with children.', 'Bulldog.jpg', 'stock'),
	(21, 'dog', 'Beagle', 'England', 1, 'Male', 16000.00, 'Small, sturdy, and known for their excellent sense of smell, Beagles are friendly, curious, and great with families.', 'Beagle.webp', 'stock'),
	(22, 'dog', 'Boxer', 'germany', 2, 'Female', 9000.00, 'Boxers are playful, energetic, and good with children. They have a distinctive square muzzle and strong build.\r\n', 'Boxer.jpg', 'sold'),
	(23, 'bird', 'Budgerigar', 'Australia', 1, 'Female', 3000.00, 'Small, social, and colorful parakeet, known for its ability to mimic human speech. Budgies are playful and thrive in pairs or flocks, making them great companions.', 'Budgerigar_bird.jpg', 'sold'),
	(24, 'bird', 'Cockatiel ', 'Australia', 2, 'Male', 5000.00, 'Friendly and affectionate bird with a distinctive crest, often enjoys whistling tunes. Cockatiels are known for their curious nature and can be trained to do simple tricks.', 'Cockatiel_bird.jpg', 'stock'),
	(25, 'bird', 'Lovebird', 'africa', 1, 'Male', 6000.00, 'Small, affectionate parrot known for its strong pair bonding and vibrant colors. Lovebirds are energetic and enjoy playing with toys and interacting with their owners.', 'Lovebird_bird.jpg', 'sold'),
	(26, 'bird', 'Macaw ', 'central and south america', 3, 'Female', 6000.00, 'Large, colorful parrot known for its striking plumage and loud calls, often very social. Macaws form strong bonds with their owners and need spacious environments to thrive.', 'Macaw_bird.jpg', 'stock'),
	(27, 'bird', 'Indian Ringneck Parakeet', 'South Asia', 4, 'Male', 5000.00, 'Medium-sized parakeet known for its striking ring around the neck and ability to mimic speech. These birds are intelligent, curious, and require regular mental stimulation.', 'Indian Ringneck Parakeet_bird.jpg', 'stock'),
	(30, 'Rabbit', 'Holland Lop', 'Netherlands', 3, 'Male', 4000.00, 'Small, friendly rabbit with distinctive floppy ears. Holland Lops are known for their sweet nature and enjoy interacting with people and other pets.', 'Holland Lop rabbit.jpg', 'stock'),
	(31, 'Rabbit', 'Mini Rex', 'france', 2, 'Female', 6000.00, 'Known for its plush, velvety fur and friendly temperament. Mini Rex rabbits are easy to handle and make excellent pets for families and individuals alike.', 'Mini Rex Rabbit.jpg', 'sold'),
	(32, 'Rabbit', 'Lionhead ', 'france', 1, 'Male', 8000.00, 'Small, fluffy rabbit with a distinctive mane of fur around its head, resembling a lion. Lionheads are curious, playful, and enjoy socializing with their owners.', 'Lionhead Rabbit.jpg', 'stock'),
	(39, 'rabbit', 'Netherland Dwarf', 'Netherlands', 2, 'Female', 10000.00, 'Smallest domestic rabbit breed, known for its compact size and playful personality. These rabbits are friendly and can be litter-trained, making them great indoor pets.', 'download.jfif', 'stock'),
	(102, 'dog', 'pomenarium', 'sri lanka', 5, 'Male', 59000.00, 'black', 'max3.jpg', 'sold'),
	(103, 'dog', 'pomenarium', 'Netherlands', 5, 'Male', 50000.00, 'koil', 'pet care.jpg', 'sold'),
	(104, 'dog', 'pomenarium', 'Netherlands', 8, 'Male', 5.00, 'jhj', 'brown pit.jpg', 'sold'),
	(105, 'bird', 'parrot', 'sri lanka', 5, 'Male', 5.00, 'hjbj', 'images.jpg', 'sold'),
	(106, 'rabbit', 'Mini Rex', 'sri lanka', 4, 'Male', 8200.00, 'white', 'lucy2-56a4a9043df78cf772838e86.jpg', 'sold'),
	(107, 'rabbit', 'hello', 'Netherland', 5, 'Male', 12000.00, 'hvhv', 'download.jfif', 'sold'),
	(112, 'dog', 'pitbull', 'ff', 8, 'Male', 5000.00, 'vv', 'black Pitbull.jpg', 'sold');
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;

-- Dumping structure for table wedding_management.pet_images
CREATE TABLE IF NOT EXISTS `pet_images` (
  `id` int NOT NULL,
  `story_id` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.pet_images: ~3 rows (approximately)
/*!40000 ALTER TABLE `pet_images` DISABLE KEYS */;
INSERT INTO `pet_images` (`id`, `story_id`, `image`) VALUES
	(86, 32, 'f5461a147b352c42aa8432f1c92a0b14.jpg'),
	(87, 32, 'df9516c41c1507eb2372213a1ba299ed.jpg'),
	(88, 32, '3e14b2b754030e986f18097f3f6a411b.jpg');
/*!40000 ALTER TABLE `pet_images` ENABLE KEYS */;

-- Dumping structure for table wedding_management.pet_stories
CREATE TABLE IF NOT EXISTS `pet_stories` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pet_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pet_age` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.pet_stories: ~0 rows (approximately)
/*!40000 ALTER TABLE `pet_stories` DISABLE KEYS */;
INSERT INTO `pet_stories` (`id`, `title`, `content`, `pet_name`, `pet_age`) VALUES
	(32, 'The Adventurous Life of Max', 'Max, a spirited golden retriever with a heart full of adventure, has always been the star of the neighborhood. From the moment he bounded into our lives as a fluffy, exuberant puppy, he brought joy, laughter, and a touch of chaos to our home.\r\n\r\nMax\'s day begins with a burst of energy. As the sun peeks over the horizon, he’s already at the door, tail wagging furiously, ready for his morning walk. The neighborhood park is his kingdom, where he reigns supreme. Every tree, bush, and bench is a new frontier to explore. His favorite game is fetch, and he never tires of chasing his bright red ball, his golden fur gleaming in the sunlight as he races across the grass.\r\n\r\nOne of Max’s most endearing quirks is his love for water. Be it a pond, a puddle, or even the garden hose, Max dives in with unabashed glee. Our weekend trips to the lake are his favorite. The moment we arrive, he leaps out of the car and makes a beeline for the water, his excitement palpable. He swims like a fish, cutting through the water with powerful strokes, his eyes sparkling with joy.\r\n\r\nBut Max’s adventures are not confined to the outdoors. He’s a curious soul, always poking his nose into every corner of the house. His curiosity has led to some hilarious incidents. Like the time he got his head stuck in the cookie jar. We heard a strange clinking sound from the kitchen and found Max, his head completely inside the jar, frantically wagging his tail. It took a bit of effort to free him, but the sight was so comical that we couldn’t stop laughing.\r\n\r\nMax is also a master of stealth. Despite his size, he moves with surprising quietness, especially when he’s up to some mischief. Once, we were puzzled by the disappearing socks. After a week of missing socks, we discovered Max’s secret stash behind the couch, where he had been hoarding them like treasures.\r\n\r\nDespite his playful nature, Max has a tender side. He senses when someone is upset and will sit quietly beside them, offering comfort with his gentle presence. His big, brown eyes seem to understand more than words ever could. During tough times, his companionship has been a source of solace, reminding us of the simple yet profound joy that pets bring into our lives.\r\n\r\nMax’s adventures took a new turn when we introduced him to hiking. The mountains became his new playground. Watching him navigate rocky trails and sniff every wildflower along the way filled us with awe. He climbed steep paths with the agility of a mountain goat and the enthusiasm of a child on Christmas morning. Camping under the stars with Max curled up beside the fire, his fur warm against the cool night air, became our cherished family tradition.\r\n\r\nEvery night, Max has a routine. After his dinner, he settles down with his favorite chew toy and gnaws on it contentedly. When bedtime comes, he curls up at the foot of our bed, his soft snores a comforting lullaby. There’s a sense of completeness, knowing he’s there, a loyal companion who has woven himself into the very fabric of our lives.\r\n\r\nMax’s adventurous spirit, his boundless energy, and his unwavering loyalty have made him more than just a pet. He’s a beloved member of our family, a source of endless joy and countless cherished memories. His story is not just about a dog’s adventures but about the love, laughter, and life lessons he has brought into our home. As we look forward to more years with Max, we know that every day will be an adventure, and every moment will be filled with love.', 'Max', '3 years');
/*!40000 ALTER TABLE `pet_stories` ENABLE KEYS */;

-- Dumping structure for table wedding_management.photography
CREATE TABLE IF NOT EXISTS `photography` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `seller_email` varchar(50) DEFAULT NULL,
  `line1` varchar(50) DEFAULT NULL,
  `line2` varchar(50) DEFAULT NULL,
  `districts_id` int DEFAULT NULL,
  `discription` text,
  `company_name` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '0',
  `pay_id` int DEFAULT NULL,
  `register_payment` double DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_photography_users` (`seller_email`),
  KEY `FK_photography_district` (`districts_id`),
  KEY `FK_photography_pay_type_2` (`pay_id`),
  CONSTRAINT `FK_photography_district` FOREIGN KEY (`districts_id`) REFERENCES `district` (`id`),
  CONSTRAINT `FK_photography_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_photography_pay_type_2` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_photography_users` FOREIGN KEY (`seller_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.photography: ~0 rows (approximately)
/*!40000 ALTER TABLE `photography` DISABLE KEYS */;
/*!40000 ALTER TABLE `photography` ENABLE KEYS */;

-- Dumping structure for table wedding_management.photography_booking
CREATE TABLE IF NOT EXISTS `photography_booking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `time_id` int DEFAULT NULL,
  `packag_id` int DEFAULT NULL,
  `hidden` int DEFAULT '0',
  `order_id` varchar(50) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `order_status` varchar(50) DEFAULT 'confirmed',
  `pay_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_photography_booking_users` (`user_email`),
  KEY `FK_photography_booking_time` (`time_id`),
  KEY `FK_photography_booking_photography_package` (`packag_id`),
  KEY `FK_photography_booking_pay_type` (`pay_id`),
  CONSTRAINT `FK_photography_booking_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_photography_booking_photography_package` FOREIGN KEY (`packag_id`) REFERENCES `photography_package` (`id`),
  CONSTRAINT `FK_photography_booking_time` FOREIGN KEY (`time_id`) REFERENCES `time` (`id`),
  CONSTRAINT `FK_photography_booking_users` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.photography_booking: ~0 rows (approximately)
/*!40000 ALTER TABLE `photography_booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `photography_booking` ENABLE KEYS */;

-- Dumping structure for table wedding_management.photography_gallary
CREATE TABLE IF NOT EXISTS `photography_gallary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `photography_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_photogaphy_gallary_photography` (`photography_id`) USING BTREE,
  CONSTRAINT `FK_photogaphy_gallary_photography` FOREIGN KEY (`photography_id`) REFERENCES `photography` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.photography_gallary: ~0 rows (approximately)
/*!40000 ALTER TABLE `photography_gallary` DISABLE KEYS */;
/*!40000 ALTER TABLE `photography_gallary` ENABLE KEYS */;

-- Dumping structure for table wedding_management.photography_package
CREATE TABLE IF NOT EXISTS `photography_package` (
  `id` int NOT NULL AUTO_INCREMENT,
  `package_type` varchar(50) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `preview_image` varchar(50) DEFAULT NULL,
  `photography_id` int DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_photography_package_photography` (`photography_id`),
  CONSTRAINT `FK_photography_package_photography` FOREIGN KEY (`photography_id`) REFERENCES `photography` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.photography_package: ~0 rows (approximately)
/*!40000 ALTER TABLE `photography_package` DISABLE KEYS */;
/*!40000 ALTER TABLE `photography_package` ENABLE KEYS */;

-- Dumping structure for table wedding_management.photography_package_features
CREATE TABLE IF NOT EXISTS `photography_package_features` (
  `id` int NOT NULL AUTO_INCREMENT,
  `package_id` int DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_photography_package_features_photography_package` (`package_id`),
  CONSTRAINT `FK_photography_package_features_photography_package` FOREIGN KEY (`package_id`) REFERENCES `photography_package` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.photography_package_features: ~0 rows (approximately)
/*!40000 ALTER TABLE `photography_package_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `photography_package_features` ENABLE KEYS */;

-- Dumping structure for table wedding_management.photography__img_logo
CREATE TABLE IF NOT EXISTS `photography__img_logo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `photography_id` int DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_photography__img_logo_photography` (`photography_id`),
  CONSTRAINT `FK_photography__img_logo_photography` FOREIGN KEY (`photography_id`) REFERENCES `photography` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.photography__img_logo: ~0 rows (approximately)
/*!40000 ALTER TABLE `photography__img_logo` DISABLE KEYS */;
/*!40000 ALTER TABLE `photography__img_logo` ENABLE KEYS */;

-- Dumping structure for table wedding_management.province
CREATE TABLE IF NOT EXISTS `province` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.province: ~9 rows (approximately)
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` (`id`, `name`) VALUES
	(1, 'Central Province '),
	(2, 'Eastern Province'),
	(3, 'Northern Province'),
	(4, 'Southern Province'),
	(5, 'Western Province'),
	(6, 'North Western Province'),
	(7, 'North Central Province'),
	(8, 'Uva Province'),
	(9, 'Sabaragamuwa Province');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;

-- Dumping structure for table wedding_management.register_payment
CREATE TABLE IF NOT EXISTS `register_payment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `seller_type` int DEFAULT NULL,
  `seller_mail` varchar(50) DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `card_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `card_year` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `card_month` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `payment_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_register_payment_user_type` (`seller_type`),
  KEY `FK_register_payment_users` (`seller_mail`),
  CONSTRAINT `FK_register_payment_user_type` FOREIGN KEY (`seller_type`) REFERENCES `user_type` (`id`),
  CONSTRAINT `FK_register_payment_users` FOREIGN KEY (`seller_mail`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.register_payment: ~0 rows (approximately)
/*!40000 ALTER TABLE `register_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `register_payment` ENABLE KEYS */;

-- Dumping structure for table wedding_management.seller_pets
CREATE TABLE IF NOT EXISTS `seller_pets` (
  `id` int NOT NULL,
  `seller_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `seller_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `seller_contact` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pet_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pet_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pet_age` int NOT NULL,
  `pet_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pet_price` decimal(10,2) NOT NULL,
  `pet_photos` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.seller_pets: ~10 rows (approximately)
/*!40000 ALTER TABLE `seller_pets` DISABLE KEYS */;
INSERT INTO `seller_pets` (`id`, `seller_name`, `seller_address`, `seller_contact`, `pet_type`, `pet_name`, `pet_age`, `pet_description`, `pet_price`, `pet_photos`) VALUES
	(1, 'ridmi', 'thulhiriya', '0775325883', 'Puppy', 'teddy', 5, 'brown color', 20000.00, 'uploads/dge85h9-962009cf-9255-4ee8-9242-f615162404e5.jpg'),
	(3, 'chethi', 'alawwa', '0775896354', 'Bird', 'parrot', 3, 'green color', 5000.00, 'uploads/budgerigar.jpg'),
	(4, 'jeewanee', 'warakapola', '0712312071', 'Puppy', 'labradoo', 5, 'drink milk and eat rice', 75000.00, 'uploads/istockphoto-469909912-612x612.jpg'),
	(5, 'dushan', 'wennoruwa', '0772412276', 'Puppy', 'labradoo', 9, 'noughty dog', 50000.00, 'uploads/cats-and-dogs.jpg'),
	(7, 'dinoshi', 'kandy', '0778956231', 'Cat', 'lankan cat', 3, 'very cute', 10000.00, 'uploads/cat.jpg'),
	(9, 'nimal', 'colombo', '0772456987', 'Cat', 'percian cat', 6, 'blue color', 15000.00, 'uploads/group-of-pets-on-white-background_Ermolaev-Alexander_Shutterstock.jpg'),
	(29, 'dinoshi sewwandi', 'no 04,madugasthenna,maharathenna,menikhinna', '0765609128', 'Puppy', 'rabbit', 8, 'black and brown color cute pupy', 12000.00, 'uploads/pet6.jpg'),
	(30, 'ishara sewwandi', 'thulhiriya', '0775325884', 'Puppy', 'pitbull', 12, 'cute puppy', 85000.00, 'uploads/brown pit.jpg'),
	(31, 'vikum gunawardana', 'galapitamada', '0775325885', 'Puppy', 'pitbull', 12, 'yrfyk', 50000.00, 'uploads/brown pit.jpg'),
	(34, 'Thavisha Saknidu', 'Badulla', '0775896325', 'Puppy', 'pitbull', 1, 'black color', 80000.00, 'uploads/black Pitbull.jpg');
/*!40000 ALTER TABLE `seller_pets` ENABLE KEYS */;

-- Dumping structure for table wedding_management.time
CREATE TABLE IF NOT EXISTS `time` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.time: ~0 rows (approximately)
/*!40000 ALTER TABLE `time` DISABLE KEYS */;
INSERT INTO `time` (`id`, `name`) VALUES
	(1, 'Day'),
	(2, 'Night');
/*!40000 ALTER TABLE `time` ENABLE KEYS */;

-- Dumping structure for table wedding_management.transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `pet_id` int NOT NULL,
  `trace_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table wedding_management.transactions: ~0 rows (approximately)
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` (`id`, `user_id`, `pet_id`, `trace_no`, `date_time`) VALUES
	(42, 17, 23, '6668a8eb9b660', '2024-06-11 21:43:39'),
	(43, 18, 18, '6668aab3b0556', '2024-06-11 21:51:15'),
	(44, 18, 13, '6668abbe30676', '2024-06-11 21:55:42'),
	(45, 18, 31, '6668ac1f606b0', '2024-06-11 21:57:19'),
	(46, 19, 25, '666b34ce4d580', '2024-06-13 20:05:02'),
	(47, 20, 10, '666b385d663fe', '2024-06-13 20:20:13'),
	(57, 26, 22, '668bc114623f9', '2024-07-08 12:36:04'),
	(58, 26, 19, '66a25aceee047', '2024-07-25 16:01:50'),
	(62, 19, 102, '66ba2e3fd178a', '2024-08-12 17:46:07'),
	(63, 19, 103, '66ba2f1fc5853', '2024-08-12 17:49:51'),
	(64, 19, 105, '66ba3071b8046', '2024-08-12 17:55:29'),
	(65, 19, 104, '66ba30958f127', '2024-08-12 17:56:05'),
	(66, 19, 106, '66bb64ced70c5', '2024-08-13 15:51:10'),
	(68, 28, 107, '66d3588c65a25', '2024-08-31 19:53:16'),
	(69, 19, 112, '66deda8e9d96f', '2024-09-09 13:22:54');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;

-- Dumping structure for table wedding_management.users
CREATE TABLE IF NOT EXISTS `users` (
  `fname` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `lname` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `register_date` datetime DEFAULT NULL,
  `user_type_id` int DEFAULT NULL,
  `verification_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`email`),
  KEY `FK_users_user_type` (`user_type_id`),
  CONSTRAINT `FK_users_user_type` FOREIGN KEY (`user_type_id`) REFERENCES `user_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.users: ~0 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table wedding_management.user_type
CREATE TABLE IF NOT EXISTS `user_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.user_type: ~0 rows (approximately)
/*!40000 ALTER TABLE `user_type` DISABLE KEYS */;
INSERT INTO `user_type` (`id`, `name`) VALUES
	(1, 'user'),
	(2, 'Hotel'),
	(3, 'Photography'),
	(4, 'Dj'),
	(5, 'Vehicle');
/*!40000 ALTER TABLE `user_type` ENABLE KEYS */;

-- Dumping structure for table wedding_management.vehical_booking
CREATE TABLE IF NOT EXISTS `vehical_booking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `booking_date` date DEFAULT NULL,
  `extra_date` int DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `vehical_detils_id` int DEFAULT NULL,
  `order_id` varchar(50) DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `hidden` int DEFAULT '0',
  `order_status` varchar(50) DEFAULT 'confirmed',
  `pay_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_vehical_booking_users` (`user_email`),
  KEY `FK_vehical_booking_vehicles_details` (`vehical_detils_id`),
  KEY `FK_vehical_booking_pay_type` (`pay_id`),
  CONSTRAINT `FK_vehical_booking_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_vehical_booking_users` FOREIGN KEY (`user_email`) REFERENCES `users` (`email`),
  CONSTRAINT `FK_vehical_booking_vehicles_details` FOREIGN KEY (`vehical_detils_id`) REFERENCES `vehicles_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.vehical_booking: ~0 rows (approximately)
/*!40000 ALTER TABLE `vehical_booking` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehical_booking` ENABLE KEYS */;

-- Dumping structure for table wedding_management.vehicles
CREATE TABLE IF NOT EXISTS `vehicles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `seller_email` varchar(50) DEFAULT NULL,
  `line1` varchar(50) DEFAULT NULL,
  `line2` varchar(50) DEFAULT NULL,
  `districts_id` int DEFAULT NULL,
  `pay_id` int DEFAULT NULL,
  `register_payment` double DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_vehicles_users` (`seller_email`),
  KEY `FK_vehicles_district` (`districts_id`),
  KEY `FK_vehicles_pay_type` (`pay_id`),
  CONSTRAINT `FK_vehicles_district` FOREIGN KEY (`districts_id`) REFERENCES `district` (`id`),
  CONSTRAINT `FK_vehicles_pay_type` FOREIGN KEY (`pay_id`) REFERENCES `pay_type` (`id`),
  CONSTRAINT `FK_vehicles_users` FOREIGN KEY (`seller_email`) REFERENCES `users` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.vehicles: ~0 rows (approximately)
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;

-- Dumping structure for table wedding_management.vehicles_condition
CREATE TABLE IF NOT EXISTS `vehicles_condition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `condition_name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.vehicles_condition: ~0 rows (approximately)
/*!40000 ALTER TABLE `vehicles_condition` DISABLE KEYS */;
INSERT INTO `vehicles_condition` (`id`, `condition_name`) VALUES
	(1, 'Ac'),
	(2, 'Non-Ac');
/*!40000 ALTER TABLE `vehicles_condition` ENABLE KEYS */;

-- Dumping structure for table wedding_management.vehicles_details
CREATE TABLE IF NOT EXISTS `vehicles_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `company_id` int NOT NULL,
  `model` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `license_no` varchar(50) DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  `condition_id` int DEFAULT NULL,
  `description` text,
  `color` varchar(50) DEFAULT NULL,
  `Price_Per_Mile` double DEFAULT NULL,
  `extra_day_price` double DEFAULT NULL,
  `vehical_number` varchar(50) DEFAULT NULL,
  `status` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_vehicles_details_vehicles-condition` (`condition_id`),
  KEY `FK_vehicles_details_vehicles` (`company_id`) USING BTREE,
  CONSTRAINT `FK_vehicles_details_vehicles` FOREIGN KEY (`company_id`) REFERENCES `vehicles` (`id`),
  CONSTRAINT `FK_vehicles_details_vehicles-condition` FOREIGN KEY (`condition_id`) REFERENCES `vehicles_condition` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.vehicles_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `vehicles_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicles_details` ENABLE KEYS */;

-- Dumping structure for table wedding_management.vehicles_img
CREATE TABLE IF NOT EXISTS `vehicles_img` (
  `id` int NOT NULL AUTO_INCREMENT,
  `img` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `vehical_de_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_vehicles_img_vehicles_details` (`vehical_de_id`),
  CONSTRAINT `FK_vehicles_img_vehicles_details` FOREIGN KEY (`vehical_de_id`) REFERENCES `vehicles_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.vehicles_img: ~0 rows (approximately)
/*!40000 ALTER TABLE `vehicles_img` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicles_img` ENABLE KEYS */;

-- Dumping structure for table wedding_management.vehicles_img_logo
CREATE TABLE IF NOT EXISTS `vehicles_img_logo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `vehical_details_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_vehicles_img_logo_vehicles_details` (`vehical_details_id`),
  CONSTRAINT `FK_vehicles_img_logo_vehicles_details` FOREIGN KEY (`vehical_details_id`) REFERENCES `vehicles_details` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table wedding_management.vehicles_img_logo: ~0 rows (approximately)
/*!40000 ALTER TABLE `vehicles_img_logo` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicles_img_logo` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
