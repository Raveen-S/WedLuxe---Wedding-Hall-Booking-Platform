<?php
require_once "header.php";

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="icon" href="images/LogoW.png" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/common.css">
    <link rel="stylesheet" href="css/home.css">
</head>

<body>



    <div id="home-page" class="display">
        <img src="images/Logo.png" alt="" class="home-logo">
        <img src="images/hwal.jpg" alt="" class="homi-wall">
        <h1 class="home-caption">create memories that will last a lifetime</h1>
    </div>

    <div id="hotels-page" class="display">
        <div class="page-title">Your Dream Wedding, One Click Away</div>
        <div class="description-block">
            <div class="card-holder">
                <div class="cards">
                    <img src="images/home-hotels.jpg" alt="" class="card-img">
                </div>
                <div class="cards">
                    <img src="images//package-photo-1.jpg" alt="" class="card-img">
                </div>
                <div class="cards">
                    <img src="images/package-photo-2.jpg" alt="" class="card-img">
                </div>
            </div>
            <div class="description-holder">
                <div class="description">
                    Discover the perfect venue to celebrate your love story. Whether you envision a grand ballroom, a charming garden, or a modern rooftop, we’ve curated the finest wedding halls for you. Tailor your special day with our bespoke wedding packages that include catering, décor, entertainment, and more. Let us take care of the details, so you can focus on creating unforgettable memories.
                </div>
                <button class="hotel-btn page-button btn-left" onclick="pageTravel('hotel-home.php')">View
                    Hotels</button>
            </div>
        </div>
        <img src="images/church.png" alt="" class="watermark wr">
    </div>

    <div id="about-page" class="display">
        <img src="images/settings.gif" alt="" class="back-gif">
        <div class="contact-details">
            <h1>About Us</h1>
            <p>Welcome to our wedding management website, where we are dedicated to creating unforgettable
                weddings that reflect your unique style and love story. Our team of professionals takes
                care of every detail, ensuring a stress-free and magical experience.
                With our creativity, attention to detail, and trusted network of vendors, we bring your vision
                to life while staying within your budget. Let us guide you through the journey of planning your
                dream wedding and creating cherished memories that will last a lifetime. Contact us today to get started!</p>
        </div>
        <img src="images/leaf.png" alt="" class="leaf">
    </div>
    </div>

    <?php
    require_once "footer.php";

    ?>
    <!-- <footer class="footer">
        <div class="header-left">
        </div>
        <nav class="header-mid" style=" justify-content: center;">
            Partnerships
        </nav>
        <div class="header-right">
        </div>
    </footer> -->



    <script src="js/common.js"></script>
    <script src="js/home.js"></script>
</body>

</html>