<footer style="background-color: #1a1a1a; color: white; text-align: center; padding: 20px; font-family: Arial, sans-serif; display:flex; align-items:center;">
    <p style="font-size: 18px; margin: 0;">&copy; 2024 Wedluxe. All Rights Reserved.</p>

    <div>
        <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Privacy Policy</a> |
        <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Terms of Service</a>
    </div>

    <div>
        <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Facebook</a>
        <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Twitter</a>
        <a href="#" style="color: white; text-decoration: none; margin: 0 10px;">Instagram</a>
    </div>
</footer>